'use strict';

// Global variables
let extensionSettings = null;
let isPageBlocked = false;

// Initialize content script
async function initialize() {
  try {
    // Get extension settings
    extensionSettings = await getExtensionSettings();
    
    // If extension is disabled, exit
    if (!extensionSettings.enabled) return;
    
    // Start monitoring page content
    analyzePageContent();
    
    // Listen for messages from background script
    chrome.runtime.onMessage.addListener(handleMessages);
    
    console.log('AI Web Filter content script initialized');
  } catch (error) {
    console.error('Failed to initialize content script:', error);
  }
}

// Get extension settings from background script
async function getExtensionSettings() {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: 'GET_SETTINGS' }, (response) => {
      resolve(response?.settings || {
        enabled: true,
        nsfwFilter: true,
        violenceFilter: true,
        suicideFilter: true,
        educationalMode: true,
        sensitivity: 'medium'
      });
    });
  });
}

// Analyze page content for inappropriate material
function analyzePageContent() {
  if (isPageBlocked) return;
  
  // Get page text content
  const pageContent = document.body.innerText;
  const url = window.location.href;
  
  // Send page content to background script for analysis
  chrome.runtime.sendMessage({
    type: 'CHECK_URL',
    url,
    content: pageContent
  }, (response) => {
    if (response && response.shouldBlock) {
      blockPage(response.reason);
    }
  });
}

// Block page and show block page
function blockPage(reason) {
  if (isPageBlocked) return;
  
  isPageBlocked = true;
  
  // Construct block page URL with reason
  const blockPageUrl = chrome.runtime.getURL('pages/block.html') + 
                      `?reason=${encodeURIComponent(reason || 'unsafe')}` + 
                      `&url=${encodeURIComponent(window.location.href)}`;
  
  // Replace entire page content with block page
  document.documentElement.innerHTML = '';
  
  // Create iframe for block page
  const iframe = document.createElement('iframe');
  iframe.src = blockPageUrl;
  iframe.style.width = '100%';
  iframe.style.height = '100%';
  iframe.style.border = 'none';
  iframe.style.position = 'fixed';
  iframe.style.top = '0';
  iframe.style.left = '0';
  iframe.style.zIndex = '2147483647'; // Maximum z-index
  
  // Append iframe to page
  document.documentElement.appendChild(iframe);
  
  // Prevent any further content loading
  window.stop();
}

// Handle messages from background script
function handleMessages(message, sender, sendResponse) {
  switch (message.type) {
    case 'SETTINGS_UPDATED':
      extensionSettings = message.settings;
      break;
    
    case 'FORCE_ANALYSIS':
      analyzePageContent();
      break;
  }
}

// Initialize the content script
initialize();